#pragma once
#include <Windows.h>
#include <iostream>
#include <fstream>
#include "CL.h"
#include <cliext/vector>

using namespace std;



class Asset
{
public:
	Asset(void);
	~Asset(void);

	
	// Encryption Algorithm
	void _stdcall CreateEncryption();
	bool _stdcall CreateDecryption();
	void _stdcall CreateEncryption(BYTE* enc);
	bool _stdcall LoadEncryption(string enc);
	BYTE* _stdcall GetEncryption();
	bool _stdcall SaveEncryption(string encFile);


	// Encrypt Files
	bool _stdcall EncryptFileA(string InFile,string OutFile);
	BYTE* _stdcall GetEncryptedFileA(string InFile,string OutFile);

	// Decrypt Files
	bool _stdcall DecryptFileA(string InFile,string OutFile);
	BYTE* _stdcall GetDecryptedFileA(string InFile,string OutFile);



	// Pack
	bool _stdcall CreateNewPack();
	bool _stdcall AddFile(string File);


	// Pack Files
	bool _stdcall Pack(string File);
	bool _stdcall PackAndEncrypt(string File);
	
	// Load Pack
	bool _stdcall LoadPack(string File);
	bool _stdcall LoadPack(BYTE* File,int offset, int length);
	

	// Get Data
	bool _stdcall GetData(string EntryName, string OutFile);
	bool _stdcall GetData(int Index, string OutFile);
	BYTE* _stdcall GetDataByte(string EntryName);
	BYTE* _stdcall GetDataByte(int Index);

	// Get Encrypted Data
	bool _stdcall GetEncryptedData(string EntryName, string OutFile);
	bool _stdcall GetEncryptedData(int Index, string OutFile);
	BYTE* _stdcall GetEncryptedDataByte(string EntryName);
	BYTE* _stdcall GetEncryptedDataByte(int Index);

	ULONG _stdcall GetFileSize(string EntryName);
	ULONG _stdcall GetFileSize(int Index);
	ULONG _stdcall GetFilesCount();
	bool _stdcall PackIsEncrypted();

	bool _stdcall ClosePack();

	struct FileEntry
{
public:
	ULONG FileSize,OffSet;
	string FileName,FullFile;;
};
private:
	FILE* fi;

//ofstream fl;
bool encrypted;
//ifstream fs;
cl<FileEntry> Files;
BYTE* Enc;
BYTE* Dec;
ULONG off;
bool isopen;

void WriteUL(ULONG value);
void WriteL(LONG value);
ULONG GetUL();
LONG GetL();
ULONG GetFileSizeF(string* File);
string GetFileName(string* File);
void WriteHeader(bool encr);
string ReadString();

};

